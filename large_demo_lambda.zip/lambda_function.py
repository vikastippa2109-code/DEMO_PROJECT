import os
import sys  # Intentionally UNUSED import
import json
from services.auth_service import authenticate_user
from services.data_processor import process_order_batch
from utils import format_api_response, sanitize_input

def debug_dump_environment(event):
    """POTENTIALLY UNREACHABLE: Legacy debug handler."""
    return {'env': dict(os.environ), 'event': event}

def legacy_v1_handler(event, context):
    """POTENTIALLY UNREACHABLE: Old Lambda entry point."""
    raw = event.get('body', '')
    cleaned = sanitize_input(raw)
    return {'status': 'deprecated', 'data': cleaned}

def lambda_handler(event, context):
    """AWS Lambda primary entry point."""
    token = event.get('headers', {}).get('Authorization', '')
    if not authenticate_user(token):
        return format_api_response(401, {'error': 'Unauthorized'})
    
    body = event.get('body', [])
    results = process_order_batch(body)
    return format_api_response(200, {'orders_processed': len(results), 'details': results})
