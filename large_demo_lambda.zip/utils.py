import datetime
import re  # Intentionally UNUSED import
import urllib.parse  # Intentionally UNUSED import

def unused_string_formatter(val):
    """POTENTIALLY UNREACHABLE: Unused string utility."""
    return f'==[ {val} ]=='

def sanitize_input(text):
    if not isinstance(text, str):
        return ''
    return text.strip().replace('<script>', '')

def format_api_response(status_code, payload):
    return {
        'statusCode': status_code,
        'headers': {'Content-Type': 'application/json'},
        'body': {
            'timestamp': str(datetime.datetime.utcnow()),
            'data': payload
        }
    }
