import time
import hashlib
import math  # Intentionally UNUSED import

def obsolete_basic_auth(username, password):
    """POTENTIALLY UNREACHABLE: Deprecated basic auth."""
    combined = f'{username}:{password}'
    return hashlib.md5(combined.encode()).hexdigest()

def verify_token_hash(token):
    if not token or len(token) < 10:
        return False
    hashed = hashlib.sha256(token.encode()).hexdigest()
    return len(hashed) == 64

def authenticate_user(token_header):
    if not token_header.startswith('Bearer '):
        return False
    raw_token = token_header.split(' ')[1]
    return verify_token_hash(raw_token)
