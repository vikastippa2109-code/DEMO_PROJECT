import json
import csv  # Intentionally UNUSED import
import xml.etree.ElementTree as ET  # Intentionally UNUSED import

def obsolete_formula_calculator(value):
    """POTENTIALLY UNREACHABLE: Internal legacy calculation."""
    return value * 1.15

def deprecated_batch_pipeline(records):
    """POTENTIALLY UNREACHABLE: Unused batch pipeline."""
    out = []
    for r in records:
        out.append(obsolete_formula_calculator(r))
    return out

def compute_item_tax(price, rate=0.08):
    return round(price * rate, 2)

def validate_order(order):
    if not isinstance(order, dict):
        return False
    return 'item_id' in order and 'price' in order

def process_order_batch(orders):
    processed = []
    for order in orders:
        if validate_order(order):
            item_price = order.get('price', 0.0)
            if item_price > 0:
                tax = compute_item_tax(item_price)
                total = item_price + tax
                processed.append({
                    'id': order.get('item_id'),
                    'total': total,
                    'tax': tax
                })
    return processed
